import SwiftUI
import CoreML

struct ContentView: View {
    @State var predictionLabel = ""
    @State var predictionProb = 0.0
    @State var rando: UIImage? = nil
    
    @State var userGuess = 0
    @State var userCorrect = false
    
    @State var userScore = 0
    
    @State var modelGuess = 0
    @State var modelCorrect = false
    
    @State var answered = false
    
    @State var start = false
    
    let delay = 5.0
    
    let mainColor = Color(#colorLiteral(red: 0.8462854028, green: 0.8526291847, blue: 0.8948717713, alpha: 1))
    
    // - Fake = 1
    // - Real = 2
    
    let answers = [1, 1, 2, 1, 2, 2, 2, 1, 2, 1, 1, 2, 1]
    let photos = ["fake1", "fake2","real1" ,"fake3", "real2", "real3","real4", "fake4", "real5", "fake5", "fake6", "real6", "real6"]
    @State var photosNum = 0
    
    func classifyDeepfake(image: String) {
        let config = MLModelConfiguration()
        config.computeUnits = .cpuOnly
        
        guard let model = try? dpdm(configuration: config) else { return }
        
        let newImage = UIImage(named: "\(image).jpg")
        print(newImage)

        let newSize = CGSize(width: 299, height: 299)
        guard let resizedImage = newImage?.resizeImageTo(size: newSize) else {
            fatalError("ResizedImage Error")
        }

        guard let convertedImage = resizedImage.convertToBuffer() else {
            fatalError("convertImage Error")
        }

        do {
            let prediction = try model.prediction(image: convertedImage)
            let mostLikelyImageCategory = prediction.classLabel
            predictionLabel = prediction.classLabel

            let probabilityOfEachCategory = prediction.classLabelProbs

            print(probabilityOfEachCategory)
            
            var highestProbability: Double {
                let probabilty = probabilityOfEachCategory[mostLikelyImageCategory] ?? 0.0
                let roundedProbability = (probabilty * 100).rounded(.toNearestOrEven)

                return roundedProbability
            }
            predictionProb=highestProbability
        } catch {
            fatalError("\(error.localizedDescription)")
        }
    }
        
    var body: some View {
        ZStack {
            VStack (spacing: 20){
                Image(photos[photosNum])
                    .resizable()
                    .cornerRadius(15)
                    .padding(10)
                    .padding([.horizontal], 25)

                Group {
                    HStack{
                        if (answered) {
                            if (modelCorrect && userCorrect) {
                                Text("Easy peasy lemon squeezy!")
                                    .bold()
                            } else if (modelCorrect && !userCorrect) {
                                Text("Foreshadowing the future?")
                                    .bold()
                            } else if (!modelCorrect && userCorrect) {
                                Text("Are humans going to be the smartest species forever?")
                                    .bold()
                            } else {
                                Text("Hard question. Better luck next time!")
                                    .bold()
                            }
                            
                            Image(systemName: "chevron.right")
                                .padding(15)
                                .background(.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .onTapGesture {
                                    if (photosNum <= 11) {
                                        photosNum += 1
                                        answered=false
                                        
                                        userGuess=0
                                        userCorrect=false
                                        
                                        modelGuess=0
                                        modelCorrect=false
                                    }
                                }
                        }
                    }
                    .padding(.horizontal, 35)
                    .font(.title3)
                    .foregroundColor(.green)
                }
                
                VStack (spacing: 20) {
                    
                    VStack (alignment: .leading) {
                        Text("Your Guess")
                            .font(.title2)
                            .bold()
                        
                        HStack(spacing: 18) {
                            Text("Fake")
                                .font(.title3)
                                .bold()
                                .padding()
                                .padding(.horizontal, 30)
                                .foregroundColor((userGuess==1) ? .white : mainColor)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(mainColor, lineWidth: 3)
                                )
                                .background((userGuess==1) ? mainColor : .white)
                                .cornerRadius(10)
                                .onTapGesture {
                                    userGuess = 1
                                    answered=false
                                }
                            
                            Text("Real")
                                .font(.title3)
                                .bold()
                                .padding()
                                .padding(.horizontal, 30)
                                .foregroundColor((userGuess==2) ? .white : mainColor)
                                .background((userGuess==2) ? mainColor : .white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(mainColor, lineWidth: 3)
                                )
                                .background((userGuess==2) ? mainColor : .white)
                                .cornerRadius(10)
                                .onTapGesture {
                                    userGuess = 2
                                    answered=false
                                }
                        }
                    }
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(userCorrect ? .green : .gray, lineWidth: userCorrect ? 3 : 1)
                    )
                    
                    VStack (alignment: .leading) {
                        HStack (alignment: .firstTextBaseline, spacing: 10){
                            Button("Run", action: {

                                classifyDeepfake(image: photos[photosNum])
                                answered=false
    //                            runModel=true
                                if (predictionLabel=="FAKE") {
                                    modelGuess = 1
                                } else {
                                    modelGuess = 2
                                }
                            })
                            .font(.title2)
                            .padding(10)
                            .foregroundColor(.white)
                            .background(mainColor)
                            .cornerRadius(10)
                            
                            
                            Text("Model's Guess")
                                .font(.title2)
                            .bold()
                        }
                        
                        HStack(spacing: 20) {
                            Text("Fake")
                                .font(.title3)
                                .bold()
                                .padding()
                                .padding(.horizontal, 30)
                                .foregroundColor((modelGuess==1) ? .white : mainColor)
                                .background((modelGuess==1) ? mainColor : .white)
                                .cornerRadius(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(mainColor, lineWidth: 2)
                                )
                            
                            Text("Real")
                                .font(.title3)
                                .bold()
                                .padding()
                                .padding(.horizontal, 30)
                                .foregroundColor((modelGuess==2) ? .white : mainColor)
                                .background((modelGuess==2) ? mainColor : .white)
                                .cornerRadius(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(mainColor, lineWidth: 2)
                                )
                        }
                    }
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(modelCorrect ? .green : .gray, lineWidth: modelCorrect ? 3 : 1)
                    )
                    
                    if (!answered) {
                        Button("Who's Right & Who's Wrong", action:{
                            if (userGuess == answers[photosNum]) {
                                userCorrect = true
                                userScore += 1
                            } else {
                                userCorrect = false
                            }
                            
                            if (modelGuess == answers[photosNum]) {
                                modelCorrect = true
                            } else {
                                modelCorrect = false
                            }
                            
                            answered = true
                        })
                            .padding()
                            .font(.title2)
                            .padding(.horizontal, 8)
                            .background(mainColor)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
            }
            .blur(radius: (photosNum==12) ? 40 : 0)
            .opacity(start ? 1 : 0)
            .animation(.easeInOut)
            
            Group {
                VStack (spacing: 10) {
                    Group {
                        Text("\((Double(userScore)/12)*100, specifier: "%.f")%")
                            .fontWeight(.heavy)
                            .font(.system(size: 100))
                            .foregroundColor(mainColor)
                            .opacity(1)
                        
                        Text("Correct")
                            .fontWeight(.heavy)
                            .font(.system(size: 50))
                            .foregroundColor(mainColor)
                            .opacity(1)
                    }
                    
                    Text("What strategies did you use to detect between deepfake and real images?")
                        .fontWeight(.heavy)
                        .font(.title2)
                        .padding()
                        .foregroundColor(.white)
                        .opacity(1)
                    
                    Text("Replay")
                        .underline()
                        .fontWeight(.heavy)
                        .font(.title2)
                        .padding()
                        .foregroundColor(mainColor)
                        .onTapGesture {
                            start = false
                            photosNum=0
                            userScore=0
                        }
                }
                .padding()
                .background(content: {
                    Rectangle()
                        .foregroundColor(.black)
                        .opacity(0.35)
                })
                .cornerRadius(10)
            }
            .padding()
            .opacity((photosNum==12 && start) ? 1 : 0)
            .animation(.easeInOut)
            
            VStack {
                VStack {
                    Text("What is deepfake?")
                        .font(.title3)
                        .fontWeight(.heavy)
                        .padding(.bottom)
                        .foregroundColor(mainColor)
                    Text("“Deepfake” (which is derived from deep learning and fake) is synthetic content in which an individual in digital media is replaced, partly or completely, by another person using deep learning. Deepfake has allowed the manipulation of individuals in digital media to state and perform actions that never occurred. Deepfake technology has let to confusion regarding the validity of information . This app is going to teach you how to identify deepfake through a healthy competition with a high-accuracy deepfake detection model. For each image, indicate whether you believe is fake or real, and run the model to see what the AI's prediction is. Then, check your answer.")
                        .font(.system(size: 20))
                }
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(.gray, lineWidth: 1)
                )
                .padding()
                .foregroundColor(.black)
            
                    
                Button("Start", action: {
                    start=true
                })
                .font(.title)
                .foregroundColor(.white)
                .padding()
                .background(mainColor)
                .cornerRadius(15)
            }
            .opacity(start ? 0 : 1)
            .animation(.easeInOut)
        }
    }
}
